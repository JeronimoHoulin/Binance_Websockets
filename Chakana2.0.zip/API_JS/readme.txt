https://www.youtube.com/watch?v=XXuUNZIQUVA&t=229s&ab_channel=MorganPage

El objetivo de este script es tomar la estructura del Fetch a la API de Binance 
presentada en el video y agregarle unas operaciones con las respuestas para sacar
la tasa implícita entre futuros y spot.
